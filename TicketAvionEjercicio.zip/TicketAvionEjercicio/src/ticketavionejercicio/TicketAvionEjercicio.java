
package ticketavionejercicio;

import java.util.Scanner;

public class TicketAvionEjercicio {
    PasajeroFrecuente pasajeroF1;   
    
    
    //private static Cliente cliente = new Cliente ("","",reserva1,pasajeroF1);
    
    private static Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        int opt;
        
        do{ // modificar vuelo?
            System.out.println("--  Menu Vuelo --");
            System.out.println("1.- Buscar Vuelo Y Reservar Vuelo");
            System.out.println("2.- Crear Vuelo");
            System.out.println("3.- Gestion de Vuelo/Compañia");
            System.out.println("4.- Cliente");
            System.out.println("5.- Salir");
            
            opt = scanner.nextInt();
            
            switch(opt){
                case 1: // los metodos staticos perteneces a la clase en si, y pueden ser llamados desde
                    // otra clase
                    Reserva.reservarVuelo();
                    break;
                case 2: // buscar y reservar vuelo
                    Vuelo.crearVuelo();
                    break;
                case 3: // asignar vuelo
                    CompañíaAérea.crearCompañia();
                    break;
                case 4:
                    break;
                case 5:
                    System.exit(0);
            }
        }while(true);
    }
    
}
