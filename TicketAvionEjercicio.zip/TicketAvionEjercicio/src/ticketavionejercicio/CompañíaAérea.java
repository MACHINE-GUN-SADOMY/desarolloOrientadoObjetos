/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticketavionejercicio;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class CompañíaAérea {
    private static Scanner scanner = new Scanner (System.in);
    private static CompañíaAérea vueloCompañia; // instanciar el objeto
    
    private String idCompañia;
    private String nombre;
    private Vuelo vuelosDisponibles; // Cadena de caracteres que contiene la
    //información de vuelos ofrecidos por la compañía. *Se agrupa en
    //una cadena de String debido a que aún no se usan colecciones.

    public CompañíaAérea() {
    }

    public CompañíaAérea(String idCompañia, String nombre, Vuelo vuelosDisponibles) {
        this.idCompañia = idCompañia;
        this.nombre = nombre;
        this.vuelosDisponibles = vuelosDisponibles;
    }
    
    // get
    public String getIdCompañia() {
        return idCompañia;
    }

    public String getNombre() {
        return nombre;
    }
    
    

    // set
    public void setIdCompañia(String idCompañia) {
        this.idCompañia = idCompañia;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Vuelo getVuelosDisponibles() {
        return vuelosDisponibles;
    }

    public void setVuelosDisponibles(Vuelo vuelosDisponibles) {
        this.vuelosDisponibles = vuelosDisponibles;
    }
    
    public static void crearCompañia(){
        scanner.nextLine();
        System.out.println("Compañia: ");
        String compañia = scanner.nextLine();
        
        System.out.println("Nombre: ");
        String nombre = scanner.nextLine();
        
        vueloCompañia.setIdCompañia(compañia);
        vueloCompañia.setNombre(nombre); 
        
        System.out.println("Compañia creada");
        
        System.out.println("Nombre" + vueloCompañia.getIdCompañia());
        System.out.println("Nombre" + vueloCompañia.getNombre());
    }    
}
