/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticketavionejercicio;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class Reserva {
    private static Scanner scanner = new Scanner (System.in);
    private static Reserva reserva1;
    public Vuelo vuelo1;
    int opccion;
    
    private Vuelo vuelo; // colaboracion de Vuelo
    private String asientoReservado;

    public Reserva() {
    }

    public Reserva(Vuelo vuelo, String asientoReservado) {
        this.vuelo = vuelo;
        this.asientoReservado = asientoReservado;
    }

    // get
    public Vuelo getVuelo() {
        return vuelo;
    }

    public String getAsientoReservado() {
        return asientoReservado;
    }

    // set
    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public void setAsientoReservado(String asientoReservado) {
        this.asientoReservado = asientoReservado;
    }

    public static void reservarVuelo(){
        
        Vuelo.comprobarVueloExiste();
        
        if (Vuelo.comprobarVueloExiste() == true){
            do{
                scanner.nextLine();
                System.out.println("-- Elija el Vuelo -- ");

                String opt = scanner.nextLine();

                if (opt == Vuelo.conseguirId()){
                    System.out.println("Vuelo" + Vuelo.conseguirId());
                }else{
                    System.out.println("Vuelo inexistente.");
                }
            }while(true);
        }
    }
}
