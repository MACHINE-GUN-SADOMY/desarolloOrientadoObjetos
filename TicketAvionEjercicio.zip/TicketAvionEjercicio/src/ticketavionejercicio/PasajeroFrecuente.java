/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticketavionejercicio;

/**
 *
 * @author Administrator
 */
public class PasajeroFrecuente {
    private String numeroPasajero; 
    private int    puntos;
    private static PasajeroFrecuente pasajeroFrecuente1;
    
    public PasajeroFrecuente() {
    }

    public PasajeroFrecuente(String numeroPasajero, int puntos) {
        this.numeroPasajero = numeroPasajero;
        this.puntos = 0;
    }

    public String getNumeroPasajero() {
        return numeroPasajero;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setNumeroPasajero(String numeroPasajero) {
        this.numeroPasajero = numeroPasajero;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }
    
    
}
