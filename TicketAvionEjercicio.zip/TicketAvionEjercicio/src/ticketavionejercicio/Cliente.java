/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticketavionejercicio;

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class Cliente {
    private static Scanner scanner = new Scanner(System.in);
    public static Cliente cliente1;
    public static Reserva reserva1;
    public static PasajeroFrecuente pasajeroFrecuente1;
    
    private String idCliente;
    private String nombre;
    private Reserva reserva; // colaboracion entre reserva
    private PasajeroFrecuente pasajeroFrecuente; // colboracion con pasajero...

    public Cliente() {
    }

    public Cliente(String idCliente, String nombre, Reserva reserva, PasajeroFrecuente pasajeroFrecuente) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.reserva = reserva;
        this.pasajeroFrecuente = pasajeroFrecuente;
    }

    // get
    public String getIdCliente() {
        return idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public Reserva getReserva() {
        return reserva;
    }

    public PasajeroFrecuente getPasajeroFrecuente() {
        return pasajeroFrecuente;
    }

    // set
    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setReserva(Reserva reserva) {
        this.reserva = reserva;
    }

    public void setPasajeroFrecuente(PasajeroFrecuente pasajeroFrecuente) {
        this.pasajeroFrecuente = pasajeroFrecuente;
    }
    
    public void crearUsuarioCliente(){
        scanner.nextLine();
        System.out.println("-- Crear Cliente --");
        
        System.out.println("Id Cliente:");
        String idClienteInput = scanner.nextLine();
        
        System.out.println("Nombre Cliente:");
        String nombreClineteInput = scanner.nextLine();

        
        cliente1 = new Cliente (idClienteInput,nombreClineteInput,reserva1,pasajeroFrecuente1);
    }
}
