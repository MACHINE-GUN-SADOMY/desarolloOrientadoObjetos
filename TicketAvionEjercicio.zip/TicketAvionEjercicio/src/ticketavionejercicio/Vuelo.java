/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ticketavionejercicio;

import java.util.Scanner;

public class Vuelo {
    private static Scanner scanner = new Scanner (System.in);
    public static Vuelo vuelo1;
    
    private String idVuelo;
    private String origen;
    private String destino;
    private String asientosDisponibles; // Cadena de caracteres que contiene la
         //disponibilidad de asientos para el vuelo. *Se agrupa en una cadena
        //de String debido a que aún no se usan colecciones

    public Vuelo() {
    }

    public Vuelo(String idVuelo, String origen, String destino, String asientosDisponibles) {
        this.idVuelo = idVuelo;
        this.origen = origen;
        this.destino = destino;
        this.asientosDisponibles = asientosDisponibles;
    }

    // get
    public String getIdVuelo() {
        return idVuelo;
    }

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public String getAsientosDisponibles() {
        return asientosDisponibles;
    }

    // set
    public void setIdVuelo(String idVuelo) {
        this.idVuelo = idVuelo;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public void setAsientosDisponibles(String asientosDisponibles) {
        this.asientosDisponibles = asientosDisponibles;
    }
    
    public static void crearVuelo(){
       System.out.println("-- Crear Vuelo --");
        
        System.out.println("Id: ");
        String idvuelo = scanner.nextLine();

        System.out.println("Origen: "); // ciudad origen del vuelo
        String origen = scanner.nextLine();
        
        System.out.println("Destino: "); // ciudad de destino
        String destino = scanner.nextLine();
        System.out.println("Asientos: "); // asientos
        String asientosDisponibles = scanner.nextLine();
        
        vuelo1 = new Vuelo (idvuelo,origen,destino,asientosDisponibles);
        
    }
    
    public static String conseguirId(){
        String idVuelo_get = vuelo1.getIdVuelo();
    return idVuelo_get ;
    }
    
    
    public static boolean comprobarVueloExiste(){
        if (vuelo1 == null){ // verififcar si el vuelo esta vacio
            System.out.println("Sin vuelos existentes");
            return false;
        }else{ // si el vuelo no es nulo busca el vuelo y llama a buscar vuelo para reservar
            // retorna true para acceder a la funcion reserva
            buscarVuelo();
            return true;
        }
    }


    public static void buscarVuelo(){
            System.out.println("-- Vuelos Disponibles --");
            System.out.println("Numero de Vuelo: " + vuelo1.idVuelo);
            System.out.println("Origen: " + vuelo1.getOrigen());
            System.out.println("Destino: " + vuelo1.getDestino());
    }
    
    @Override
    public String toString() {
        return "Asientos Disponibles; " + asientosDisponibles;
    }
    
    
}
